import torch
import numpy as np
import torch_geometric.transforms as T
from torch_geometric.datasets import Planetoid, Amazon, Flickr
from torch_geometric.data import Data
from torch_geometric.utils import contains_self_loops, add_remaining_self_loops, to_undirected, is_undirected, contains_isolated_nodes
from pygod.utils import load_data
from pygod.generator import gen_contextual_outliers, gen_structural_outliers
from collections import Counter

path = '../../Data/'

pyg_data = Planetoid(path + 'Cora', 'Cora', transform=T.NormalizeFeatures())[0]
ls = pyg_data.y.numpy()
print(Counter(ls), len(ls))

data_dict = pyg_data.to_dict()
node_feats = data_dict['x']
edge_index = data_dict['edge_index']
labels = data_dict['y'] 
ano_mask = labels == 6
labels[ano_mask] = 1
labels[~ano_mask] = 0

ls = labels.numpy()
print(Counter(ls), len(ls))

# pyg_data = Planetoid(path + 'Citeseer', 'CiteSeer', transform=T.NormalizeFeatures())[0]
# ls = pyg_data.y.numpy()
# print(Counter(ls), len(ls))

# pyg_data = Amazon(path + 'Amazon', 'Computers', transform=T.NormalizeFeatures())[0]
# ls = pyg_data.y.numpy()
# print(Counter(ls), len(ls))